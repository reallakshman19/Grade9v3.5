# PHY-NLM-01 P1 input handoff v1

This archive supplies actual local bytes. It is a pinned SOURCE SUBSET, not a complete repository archive or a Git checkout. It contains no new implementation fixes.

## Contents and permitted use

- candidate/: nine exact PR299 files at 455103ad312ab8b6627aa7a1199b0bd7d5b0af8e. The unmodified validator, bank, adapter, two blueprints and existing regression test are runnable here. Compiler/prerender files are reference only; do not run the custom compiler to publish.
- main-context/: forty exact main files at bec62ff685baeeeb4fafbc345fba87c91f64b08d, including shared renderer/schema/Core/QRT contracts and canonical NLM capability packages. This is architecture/ownership context, NOT a full baseline or promised complete renderer dependency tree.
- owner-fixtures/: exact original Core1 PDF, Core2 PDF and uploaded standalone HTML. The HTML is NOT the current PR299 HTML.
- reading-copy/: verified Markdown and linked page PNGs; original PDFs remain authoritative.
- coordinator-replay/: actual Oracle execution logs of unchanged candidate inputs. Standard and strict bank runs exited 0; the existing focused NLM regression file ran seven tests successfully. These coupled checker results are NOT scientific approval, independent learner evidence or the other agent's claimed 19-test result.
- source-manifest.json: exact per-file SHA-256 and pinned Git blob/revision where applicable.

## First: verify local bytes

Use a checksum tool to check source-manifest.json against the extracted files. Do not infer source identity from a renamed directory or invent a local Git HEAD.

## Execute existing checks without network or full checkout

From the extracted PHY-NLM-P1-INPUTS/candidate directory:

    python scripts/physics_pipeline_validator.py --bank TEST/physics-research/question_bank_mechanics_grade9.v1.json --adapters Physics/adapter/TopicAdapters.v1.json
    python scripts/physics_pipeline_validator.py --bank TEST/physics-research/question_bank_mechanics_grade9.v1.json --adapters Physics/adapter/TopicAdapters.v1.json --strict-golden
    python -m unittest discover -s tests -p test_physics_pipeline_nlm_fix1.py -v

These commands were actually executed by the Oracle against the exact included sources; see coordinator-replay/. Preserve originals and run requested additional mutations on disposable copies. A complete main checkout is not required for these bank-validator checks.

## Browser and source checks

Open owner-fixtures/uploaded-master.html locally in the existing Chromium environment; use a local HTTP server if the available automation requires it. Inspect 001/021 pre-attempt hint behavior, solution gates and actual repair/return behavior. Runtime observations remain the coding agent's task; this ZIP does not certify them.

The original PDFs are now present locally. Use reading-copy/ for repeated reading and the PDFs for source/layout questions. Do not rerun conversion unnecessarily.

## Correct the proposed source-bank path

Main Shared/tools/render_core.py explicitly rejects an Owner-supplied bank whose parent directory is exam-bank. Do not use Physics/library/exam-bank/nlm-owner-supplied.v1.json. A proposed location within the existing task scope is Physics/content/nlm-qrt-pilot/owner-supplied-bank.v1.json, referenced through the native manifest bank_refs. Verify the owner-bank schema contract and exact capability joins before implementing.

## Remaining limits

This archive does not contain the full main test suite, all renderer/runtime dependencies/assets, complete PR299 tree, or the coding agent's 102-file evidence ZIP. Do not claim full repository baseline or integrated generation from it. Complete the now-runnable P1 validator/browser/source checks, review the exact native data boundaries, and name concrete remaining dependencies rather than treating every check as blocked by the full checkout.

Whole task AC01-AC12 and Owner approval/merge/publication boundaries remain unchanged. Return the actual evidence ZIP/link, complete proposed label/plan/criteria and real execution witnesses. Do not fabricate native admission or move to production fixes merely because the existing checker says PASS.
